let d = new Date();
document.body.innerHTML = "Você acessou esse site às: " + d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();