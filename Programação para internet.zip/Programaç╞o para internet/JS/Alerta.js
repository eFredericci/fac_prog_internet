function mostraAlerta() {
  alert("Funciona!");
}